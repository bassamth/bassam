package com.ceramica.clientes;

public class Cliente {
    private String nombre;
    private String ciudad;
    private int saldo;

    public Cliente(String nombre, String ciudad, int saldo) {
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.saldo = saldo;
    }

    public String getNombre() { return nombre; }
    public String getCiudad() { return ciudad; }
    public int getSaldo() { return saldo; }
}
