package com.ceramica.clientes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class ClienteAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<Cliente> lista;

    public ClienteAdapter(Context context, ArrayList<Cliente> lista) {
        this.context = context;
        this.lista = lista;
    }

    @Override
    public int getCount() {
        return lista.size();
    }

    @Override
    public Object getItem(int i) {
        return lista.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_cliente, parent, false);
        }

        TextView textNombre = convertView.findViewById(R.id.textNombre);
        TextView textCiudad = convertView.findViewById(R.id.textCiudad);
        TextView textSaldo = convertView.findViewById(R.id.textSaldo);

        Cliente cliente = lista.get(i);

        textNombre.setText(cliente.getNombre());
        textCiudad.setText(cliente.getCiudad());
        textSaldo.setText(String.valueOf(cliente.getSaldo()));

        return convertView;
    }
}
