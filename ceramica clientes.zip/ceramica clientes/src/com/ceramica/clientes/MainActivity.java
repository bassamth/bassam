package com.ceramica.clientes;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends Activity {

    private ListView listViewClientes;
    private TextView textTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ربط العناصر بالواجهة
        listViewClientes = (ListView) findViewById(R.id.listViewClientes);
        textTotal = (TextView) findViewById(R.id.textTotal);

        // بيانات تجريبية
        ArrayList<Cliente> clientes = new ArrayList<>();
        clientes.add(new Cliente("Leanne Graham", "Jacksonville", 200));
        clientes.add(new Cliente("Ervin Howell", "Orlando", 120));
        clientes.add(new Cliente("Clementine Bauch", "Tampa", 100));
        clientes.add(new Cliente("Patricia Lebsack", "Miami", 100));

        // حساب المجموع
        int total = 0;
        for (Cliente c : clientes) {
            total += c.getSaldo();
        }
        textTotal.setText(String.valueOf(total));

        // عرض القائمة
        ClienteAdapter adapter = new ClienteAdapter(this, clientes);
        listViewClientes.setAdapter(adapter);
    }
}